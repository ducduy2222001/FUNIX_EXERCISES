const Detail = () => {
  return (
    <div>
      <h1>Detail Page</h1>
    </div>
  );
};

export default Detail;
